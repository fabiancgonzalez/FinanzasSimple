// Script específico para la página de LOGIN
// No debe afectar a otras páginas

// DEFINIR FUNCIÓN GLOBAL PRIMERO - Antes que cualquier otra cosa
window.switchTab = function(tab) {
    // Ocultar todos los tabs
    document.querySelectorAll('.tab-content').forEach(el => {
        el.classList.remove('active');
    });
    document.querySelectorAll('.tab-btn').forEach(el => {
        el.classList.remove('active');
    });

    // Mostrar el tab seleccionado
    document.getElementById(tab).classList.add('active');
    event.target.classList.add('active');
};

// Configuración global - Usar valores inyectados por el servidor o detectar dinámicamente
let BASE_URL = window.BASE_URL;
let API_BASE = window.API_BASE;

// Si no están inyectados, detectar dinámicamente
if (!BASE_URL) {
    const currentPath = window.location.pathname;
    BASE_URL = currentPath.includes('/login') 
        ? currentPath.substring(0, currentPath.lastIndexOf('/login'))
        : (currentPath.includes('/') ? currentPath.substring(0, currentPath.lastIndexOf('/')) : '/finanzas');
}

if (!API_BASE) {
    API_BASE = BASE_URL + '/api';
}

const APP_BASE = BASE_URL;

console.log('=== LOGIN PAGE CONFIG ===');
console.log('BASE_URL:', BASE_URL);
console.log('API_BASE:', API_BASE);
console.log('APP_BASE:', APP_BASE);
console.log('switchTab available:', typeof window.switchTab);
console.log('=== END CONFIG ===');

// LOGIN
document.getElementById('loginForm').addEventListener('submit', async (e) => {
    e.preventDefault();

    const username = document.getElementById('loginUsername').value;
    const password = document.getElementById('loginPassword').value;
    const messageEl = document.getElementById('loginMessage');

    const loginURL = `${API_BASE}/login`;
    console.log('[LOGIN] Intentando login en:', loginURL);
    console.log('[LOGIN] Username:', username);

    try {
        const response = await fetch(loginURL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ username, password })
        });

        console.log('[LOGIN] Response status:', response.status);
        console.log('[LOGIN] Response ok:', response.ok);

        const data = await response.json();
        console.log('[LOGIN] Response data:', data);

        if (response.ok) {
            // Guardar token
            localStorage.setItem('token', data.token);
            localStorage.setItem('user', JSON.stringify(data.user));

            // Mostrar mensaje
            messageEl.textContent = '¡Bienvenido! Redirigiendo...';
            messageEl.classList.add('success', 'show');

            // Redirigir
            setTimeout(() => {
                window.location.href = `${APP_BASE}/`;
            }, 1500);
        } else {
            messageEl.textContent = data.error || 'Error al iniciar sesión';
            messageEl.classList.remove('success');
            messageEl.classList.add('error', 'show');
        }
    } catch (error) {
        console.error('[LOGIN] Error:', error);
        messageEl.textContent = 'Error de conexión: ' + error.message;
        messageEl.classList.remove('success');
        messageEl.classList.add('error', 'show');
    }
});

// REGISTER
document.getElementById('registerForm').addEventListener('submit', async (e) => {
    e.preventDefault();

    const username = document.getElementById('regUsername').value;
    const email = document.getElementById('regEmail').value;
    const password = document.getElementById('regPassword').value;
    const passwordConfirm = document.getElementById('regPasswordConfirm').value;
    const messageEl = document.getElementById('registerMessage');

    if (password !== passwordConfirm) {
        messageEl.textContent = 'Las contraseñas no coinciden';
        messageEl.classList.remove('success');
        messageEl.classList.add('error', 'show');
        return;
    }

    const registerURL = `${API_BASE}/register`;
    console.log('[REGISTER] Intentando registro en:', registerURL);
    console.log('[REGISTER] Username:', username, 'Email:', email);

    try {
        const response = await fetch(registerURL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ username, email, password })
        });

        console.log('[REGISTER] Response status:', response.status);
        const data = await response.json();
        console.log('[REGISTER] Response data:', data);

        if (response.ok) {
            messageEl.textContent = '¡Registro exitoso! Por favor inicia sesión.';
            messageEl.classList.add('success', 'show');
            messageEl.classList.remove('error');

            // Limpiar formulario
            document.getElementById('registerForm').reset();

            // Cambiar a login
            setTimeout(() => {
                window.switchTab('login');
                document.getElementById('loginForm').reset();
            }, 2000);
        } else {
            messageEl.textContent = data.error || 'Error al registrarse';
            messageEl.classList.remove('success');
            messageEl.classList.add('error', 'show');
        }
    } catch (error) {
        console.error('[REGISTER] Error:', error);
        messageEl.textContent = 'Error de conexión: ' + error.message;
        messageEl.classList.remove('success');
        messageEl.classList.add('error', 'show');
    }
});

// Verificar si ya está logueado
window.addEventListener('load', () => {
    if (localStorage.getItem('token')) {
        window.location.href = APP_BASE + '/';
    }
});
