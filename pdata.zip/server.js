const express = require('express');
const path = require('path');
const fs = require('fs');
const ExcelJS = require('exceljs');
const app = express();
const PORT = process.env.PORT || 3000;

// Obtener base URL desde variable de entorno o usar /finanzas como default
const BASE_URL = process.env.BASE_URL || '/finanzas';

// Middleware
app.use(express.json());

// Prevenir cache para desarrollo/testing
app.use((req, res, next) => {
  res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0');
  res.setHeader('Pragma', 'no-cache');
  res.setHeader('Expires', '0');
  next();
});

// Security headers
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('X-XSS-Protection', '1; mode=block');
  next();
});

// Ruta raíz que redirige a BASE_URL
app.get('/', (req, res) => {
  res.redirect(BASE_URL + '/');
});

// Rutas específicas ANTES de archivos estáticos
app.get(BASE_URL + '/login', (req, res) => {
  let html = fs.readFileSync(path.join(__dirname, 'public', 'login.html'), 'utf-8');
  // Inyectar la BASE_URL en el HTML para que esté disponible antes del script
  const script = `<script>
  window.BASE_URL = "${BASE_URL}";
  window.API_BASE = "${BASE_URL}/api";
  console.log('[Server Config] BASE_URL:', window.BASE_URL);
  console.log('[Server Config] API_BASE:', window.API_BASE);
</script>`;
  html = html.replace('</head>', script + '</head>');
  res.send(html);
});

app.get(BASE_URL + '/', (req, res) => {
  let html = fs.readFileSync(path.join(__dirname, 'public', 'index.html'), 'utf-8');
  // Inyectar la BASE_URL en el HTML para que esté disponible antes del script
  const script = `<script>
  window.BASE_URL = "${BASE_URL}";
  window.API_BASE = "${BASE_URL}/api";
  console.log('[Server Config] BASE_URL:', window.BASE_URL);
  console.log('[Server Config] API_BASE:', window.API_BASE);
</script>`;
  html = html.replace('</head>', script + '</head>');
  res.send(html);
});

// Servir archivos estáticos desde BASE_URL
app.use(BASE_URL, express.static('public'));

// Funciones de gestión de usuarios JSON
const dataPath = path.join(__dirname, 'data', 'users.json');

function readUsers() {
  try {
    const data = fs.readFileSync(dataPath, 'utf-8');
    return JSON.parse(data);
  } catch (error) {
    console.error('Error reading users file:', error);
    return { users: [] };
  }
}

function saveUsers(data) {
  try {
    fs.writeFileSync(dataPath, JSON.stringify(data, null, 2), 'utf-8');
  } catch (error) {
    console.error('Error saving users file:', error);
  }
}

function findUserByUsername(username) {
  const data = readUsers();
  return data.users.find(u => u.username === username);
}

// Middleware de autenticación
function requireAuth(req, res, next) {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) {
    return res.status(401).json({ error: 'No autorizado' });
  }
  
  try {
    const decoded = JSON.parse(Buffer.from(token, 'base64').toString('utf-8'));
    req.user = decoded;
    next();
  } catch (error) {
    res.status(401).json({ error: 'Token inválido' });
  }
}

// Rutas de autenticación

// Registro
app.post(BASE_URL + '/api/register', (req, res) => {
  const { username, email, password } = req.body;
  
  if (!username || !email || !password) {
    return res.status(400).json({ error: 'Faltan datos' });
  }
  
  const data = readUsers();
  
  if (data.users.find(u => u.username === username)) {
    return res.status(400).json({ error: 'El usuario ya existe' });
  }
  
  const newUser = {
    id: Date.now(),
    username,
    email,
    password,
    ingresos: [],
    egresos: []
  };
  
  data.users.push(newUser);
  saveUsers(data);
  
  res.json({ 
    message: 'Usuario registrado exitosamente',
    user: { id: newUser.id, username: newUser.username, email: newUser.email }
  });
});

// Login
app.post(BASE_URL + '/api/login', (req, res) => {
  const { username, password } = req.body;
  
  if (!username || !password) {
    return res.status(400).json({ error: 'Faltan datos' });
  }
  
  const user = findUserByUsername(username);
  
  if (!user || user.password !== password) {
    return res.status(401).json({ error: 'Usuario o contraseña incorrectos' });
  }
  
  const token = Buffer.from(JSON.stringify({
    id: user.id,
    username: user.username,
    email: user.email
  })).toString('base64');
  
  res.json({ 
    token,
    user: { id: user.id, username: user.username, email: user.email }
  });
});

// Obtener usuario actual
app.get(BASE_URL + '/api/me', requireAuth, (req, res) => {
  res.json(req.user);
});

// Rutas API
app.get(BASE_URL + '/api/transacciones', requireAuth, (req, res) => {
  const user = findUserByUsername(req.user.username);
  
  if (!user) {
    return res.status(404).json({ error: 'Usuario no encontrado' });
  }
  
  const totalIngresos = user.ingresos.reduce((sum, item) => sum + item.monto, 0);
  const totalEgresos = user.egresos.reduce((sum, item) => sum + item.monto, 0);
  const balance = totalIngresos - totalEgresos;

  res.json({
    ingresos: user.ingresos,
    egresos: user.egresos,
    totalIngresos,
    totalEgresos,
    balance
  });
});

app.post(BASE_URL + '/api/ingresos', requireAuth, (req, res) => {
  const { descripcion, monto } = req.body;
  
  if (!descripcion || !monto || monto <= 0) {
    return res.status(400).json({ error: 'Datos inválidos' });
  }

  const data = readUsers();
  const user = data.users.find(u => u.username === req.user.username);
  
  if (!user) {
    return res.status(404).json({ error: 'Usuario no encontrado' });
  }

  const nuevoIngreso = {
    id: Date.now(),
    descripcion,
    monto: parseFloat(monto),
    fecha: new Date().toLocaleString('es-ES')
  };

  user.ingresos.push(nuevoIngreso);
  saveUsers(data);
  
  res.json(nuevoIngreso);
});

app.post(BASE_URL + '/api/egresos', requireAuth, (req, res) => {
  const { descripcion, monto } = req.body;
  
  if (!descripcion || !monto || monto <= 0) {
    return res.status(400).json({ error: 'Datos inválidos' });
  }

  const data = readUsers();
  const user = data.users.find(u => u.username === req.user.username);
  
  if (!user) {
    return res.status(404).json({ error: 'Usuario no encontrado' });
  }

  const nuevoEgreso = {
    id: Date.now(),
    descripcion,
    monto: parseFloat(monto),
    fecha: new Date().toLocaleString('es-ES')
  };

  user.egresos.push(nuevoEgreso);
  saveUsers(data);
  
  res.json(nuevoEgreso);
});

app.delete(BASE_URL + '/api/ingresos/:id', requireAuth, (req, res) => {
  const id = parseInt(req.params.id);
  const data = readUsers();
  const user = data.users.find(u => u.username === req.user.username);
  
  if (!user) {
    return res.status(404).json({ error: 'Usuario no encontrado' });
  }
  
  user.ingresos = user.ingresos.filter(item => item.id !== id);
  saveUsers(data);
  
  res.json({ success: true });
});

app.delete(BASE_URL + '/api/egresos/:id', requireAuth, (req, res) => {
  const id = parseInt(req.params.id);
  const data = readUsers();
  const user = data.users.find(u => u.username === req.user.username);
  
  if (!user) {
    return res.status(404).json({ error: 'Usuario no encontrado' });
  }
  
  user.egresos = user.egresos.filter(item => item.id !== id);
  saveUsers(data);
  
  res.json({ success: true });
});

app.get(BASE_URL + '/api/exportar-excel', requireAuth, async (req, res) => {
  try {
    const user = findUserByUsername(req.user.username);
    
    if (!user) {
      return res.status(404).json({ error: 'Usuario no encontrado' });
    }
    
    const workbook = new ExcelJS.Workbook();
    
    // Hoja de Resumen
    const resumenSheet = workbook.addWorksheet('Resumen');
    resumenSheet.columns = [
      { header: 'Concepto', key: 'concepto', width: 20 },
      { header: 'Monto', key: 'monto', width: 15 }
    ];
    
    const totalIngresos = user.ingresos.reduce((sum, item) => sum + item.monto, 0);
    const totalEgresos = user.egresos.reduce((sum, item) => sum + item.monto, 0);
    const balance = totalIngresos - totalEgresos;
    
    resumenSheet.addRow({ concepto: 'Total Ingresos', monto: totalIngresos });
    resumenSheet.addRow({ concepto: 'Total Egresos', monto: totalEgresos });
    resumenSheet.addRow({ concepto: 'Balance', monto: balance });
    
    // Estilo para el resumen
    resumenSheet.getRow(1).font = { bold: true, color: { argb: 'FFFFFFFF' } };
    resumenSheet.getRow(1).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF4472C4' } };
    resumenSheet.getRow(4).font = { bold: true };
    
    // Hoja de Ingresos
    const ingresosSheet = workbook.addWorksheet('Ingresos');
    ingresosSheet.columns = [
      { header: 'Descripción', key: 'descripcion', width: 30 },
      { header: 'Monto', key: 'monto', width: 15 },
      { header: 'Fecha', key: 'fecha', width: 20 }
    ];
    
    user.ingresos.forEach(ingreso => {
      ingresosSheet.addRow({
        descripcion: ingreso.descripcion,
        monto: ingreso.monto,
        fecha: ingreso.fecha
      });
    });
    
    ingresosSheet.getRow(1).font = { bold: true, color: { argb: 'FFFFFFFF' } };
    ingresosSheet.getRow(1).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF70AD47' } };
    
    // Hoja de Egresos
    const egresosSheet = workbook.addWorksheet('Egresos');
    egresosSheet.columns = [
      { header: 'Descripción', key: 'descripcion', width: 30 },
      { header: 'Monto', key: 'monto', width: 15 },
      { header: 'Fecha', key: 'fecha', width: 20 }
    ];
    
    user.egresos.forEach(egreso => {
      egresosSheet.addRow({
        descripcion: egreso.descripcion,
        monto: egreso.monto,
        fecha: egreso.fecha
      });
    });
    
    egresosSheet.getRow(1).font = { bold: true, color: { argb: 'FFFFFFFF' } };
    egresosSheet.getRow(1).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFF4B183' } };
    
    // Configurar respuesta
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename=finanzas_${new Date().toISOString().split('T')[0]}.xlsx`);
    
    await workbook.xlsx.write(res);
    res.end();
  } catch (error) {
    console.error('Error al generar Excel:', error);
    res.status(500).json({ error: 'Error al generar el archivo Excel' });
  }
});

// Descargar datos en JSON
app.get(BASE_URL + '/api/descargar-datos', requireAuth, (req, res) => {
  try {
    const user = findUserByUsername(req.user.username);
    
    if (!user) {
      return res.status(404).json({ error: 'Usuario no encontrado' });
    }
    
    const datosUsuario = {
      usuario: user.username,
      email: user.email,
      fechaExportacion: new Date().toLocaleString('es-ES'),
      ingresos: user.ingresos,
      egresos: user.egresos,
      totalIngresos: user.ingresos.reduce((sum, item) => sum + item.monto, 0),
      totalEgresos: user.egresos.reduce((sum, item) => sum + item.monto, 0),
      balance: user.ingresos.reduce((sum, item) => sum + item.monto, 0) - 
               user.egresos.reduce((sum, item) => sum + item.monto, 0)
    };
    
    const dataStr = JSON.stringify(datosUsuario, null, 2);
    const filename = `finanzas_${user.username}_${new Date().toISOString().split('T')[0]}.json`;
    
    res.setHeader('Content-Type', 'application/json');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.setHeader('Content-Length', Buffer.byteLength(dataStr));
    
    res.send(dataStr);
  } catch (error) {
    console.error('Error al descargar datos:', error);
    res.status(500).json({ error: 'Error al descargar los datos' });
  }
});

// Cargar datos desde JSON
app.post(BASE_URL + '/api/cargar-datos', requireAuth, (req, res) => {
  try {
    const { ingresos, egresos } = req.body;
    
    if (!Array.isArray(ingresos) || !Array.isArray(egresos)) {
      return res.status(400).json({ error: 'Formato de datos inválido' });
    }
    
    const data = readUsers();
    const user = data.users.find(u => u.username === req.user.username);
    
    if (!user) {
      return res.status(404).json({ error: 'Usuario no encontrado' });
    }
    
    // Reemplazar datos
    user.ingresos = ingresos;
    user.egresos = egresos;
    
    saveUsers(data);
    
    res.json({ 
      message: 'Datos cargados exitosamente',
      ingresosCount: ingresos.length,
      egresosCount: egresos.length
    });
  } catch (error) {
    console.error('Error al cargar datos:', error);
    res.status(500).json({ error: 'Error al cargar los datos' });
  }
});

// Obtener datos guardados del usuario
app.get(BASE_URL + '/api/obtener-datos-guardados', requireAuth, (req, res) => {
  try {
    const user = findUserByUsername(req.user.username);
    
    if (!user) {
      return res.status(404).json({ error: 'Usuario no encontrado' });
    }
    
    res.json({
      usuario: user.username,
      email: user.email,
      ingresos: user.ingresos,
      egresos: user.egresos,
      totalIngresos: user.ingresos.reduce((sum, item) => sum + item.monto, 0),
      totalEgresos: user.egresos.reduce((sum, item) => sum + item.monto, 0),
      balance: user.ingresos.reduce((sum, item) => sum + item.monto, 0) - 
               user.egresos.reduce((sum, item) => sum + item.monto, 0)
    });
  } catch (error) {
    console.error('Error al obtener datos:', error);
    res.status(500).json({ error: 'Error al obtener los datos' });
  }
});

// Iniciar servidor
app.listen(PORT, () => {
  console.log(`\n🚀 Servidor iniciado en http://localhost:${PORT}`);
  console.log(`📊 Abre tu navegador en http://localhost:${PORT}\n`);
});
